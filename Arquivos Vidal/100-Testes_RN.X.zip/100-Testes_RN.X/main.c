/***********************************************************************
 * BB_LoRa:     Break Out Board for LoRa
 * 
 * Designed to be used with Curiosity or stand alone
 * 
 * Vidal P Silva Jr
 * www.vidal.com.br
 * 
 * Rev.: 1
 * 
 * 30/03/2016
 * 
 **********************************************************************/

#define CURIOSITY

#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/RN__funcoes.h"
///////////////////////////// K's
#define  K_TimeOutMs      2000          

///---- flags
volatile uint8_t fOK;
volatile uint8_t fTXOK;
volatile uint8_t fJoined;
volatile uint8_t fCRLF;
volatile uint8_t fTimeout;

///---- vars interr
volatile uint8_t indice;
volatile uint8_t DadosRecebidos[64];
volatile uint8_t PenultimoDadoRecebido;
volatile uint8_t UltimoDadoRecebido;
volatile uint16_t   tempoTimeout;

uint8_t  passagem,tempSimulada;
uint8_t  lora_port;
uint8_t  segundos;
uint8_t  centena, dezena,unidade,resto;

//@@@@@@@@@@@@@@@@@@@@@@@ LoRa Defs
uint8_t  loop;


const uint8_t deveui[16] = 
{'0','0','0','4','A','3',				
 '0','0',
 '0','2','0','1','5','5',
 'F','0'};				// TCC Maua, usar de F0 até FF (16 nodes)

const uint8_t devaddr[8] =                      // no servidor > network address
{'0','2','0','1','5','5',
 'F','0'};				// TCC Maua, usar de F0 até FF (16 nodes)

const uint8_t appskey[32] = 
{'2','B','7','E','1','5','1','6','2','8','A','E','D','2','A','6',
 'A','B','F','7','1','5','8','8','0','9','C','F','4','F','3','C'};

const uint8_t nwkskey[32] = 
{'2','B','7','E','1','5','1','6','2','8','A','E','D','2','A','6',
 'A','B','F','7','1','5','8','8','0','9','C','F','4','F','3','C'};

const uint8_t appeui[16] = 
{'A','A','A','A','A','A','A','A','0','0','0','0','0','0','0','1'};

void timeout()
{
    __delay_ms(10);
    tempoTimeout-=10;
    if (tempoTimeout<10)
        fTimeout=true;
}

/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
/*        Main application     */
void main(void)
{
    SYSTEM_Initialize();
    rstrn_SetLow();

#ifdef CURIOSITY
    for (uint8_t x=0;x<3;x++)
    {
        LED_D4_SetHigh();
        __delay_ms(25);
        LED_D4_SetLow();
        __delay_ms(25);
    }
#endif
    
    passagem=1;
    lora_port=250;          // varia de 1 a 223
    segundos=10;
    fOK=false;
    fTXOK=false;
    fJoined=false;

    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();

    __RN_HWReset();             // after reset the module takes 100 ms to put the txp pin HIGH
                                // and more 80-90 ms to send the reset message
    
    tempoTimeout = K_TimeOutMs;
    fTimeout=false;
    fCRLF=false;
    while (!fCRLF)
    {
        timeout();
        if (fTimeout)
            break;
    }
    if (fTimeout)
        __RN_flash_GPIO6(10);
    __delay_ms(10);
    
    __RN_SetGpioIn(8);         // GPIO8 entrada - no reset sao saidas ativas em 0
    __delay_ms(250);
    
    __RN_WriteGpio(6,1);
#ifdef CURIOSITY
    LED_D4_SetHigh();
#endif    
    __delay_ms(1000);
    __RN_WriteGpio(6,0);
#ifdef CURIOSITY    
    LED_D4_SetLow();
#endif
    __delay_ms(200);
    __delay_ms(10);     // break point
    
    //######################################################################
    // 1) deveui
    __RN_MacSet();          //  envia "mac set "
    EUSART_Write ('d');    EUSART_Write ('e');    EUSART_Write ('v');
    EUSART_Write ('e');    EUSART_Write ('u');    EUSART_Write ('i');    EUSART_Write (' ');
    for (loop=0;loop<16;loop++)
        EUSART_Write (deveui[loop]);
    EUSART_Write (0x0d);
    EUSART_Write (0x0a);

    tempoTimeout = K_TimeOutMs;
    fTimeout=false;
    fOK=false;
    while (!fOK)
    {
        timeout();
        if (fTimeout)
            break;
    }
    if (fTimeout)
        __RN_flash_GPIO6(10);
    __delay_ms(10);

    // 2) devaddr
    __RN_MacSet();          //  envia "mac set "
    EUSART_Write ('d');    EUSART_Write ('e');    EUSART_Write ('v');
    EUSART_Write ('a');    EUSART_Write ('d');    EUSART_Write ('d');    EUSART_Write ('r');    
    EUSART_Write (' ');
    for (loop=0;loop<8;loop++)
        EUSART_Write (devaddr[loop]);
    EUSART_Write (0x0d);
    EUSART_Write (0x0a);

    tempoTimeout = K_TimeOutMs;
    fTimeout=false;
    fOK=false;
    while (!fOK)
    {
        timeout();
        if (fTimeout)
            break;
    }
    if (fTimeout)
        __RN_flash_GPIO6(10);
    __delay_ms(10);

    // 3) appskey
    __RN_MacSet();          //  envia "mac set "
    EUSART_Write ('a');    EUSART_Write ('p');    EUSART_Write ('p');
    EUSART_Write ('s');    EUSART_Write ('k');    EUSART_Write ('e');    EUSART_Write ('y');    
    EUSART_Write (' ');
    for (loop=0;loop<32;loop++)
        EUSART_Write (appskey[loop]);
    EUSART_Write (0x0d);
    EUSART_Write (0x0a);

    tempoTimeout = K_TimeOutMs;
    fTimeout=false;
    fOK=false;
    while (!fOK)
    {
        timeout();
        if (fTimeout)
            break;
    }
    if (fTimeout)
        __RN_flash_GPIO6(10);
    __delay_ms(10);

    // 4) nwkskey
    __RN_MacSet();          //  envia "mac set "
    EUSART_Write ('n');    EUSART_Write ('w');    EUSART_Write ('k');
    EUSART_Write ('s');    EUSART_Write ('k');    EUSART_Write ('e');    EUSART_Write ('y');    
    EUSART_Write (' ');
    for (loop=0;loop<32;loop++)
        EUSART_Write (nwkskey[loop]);
    EUSART_Write (0x0d);
    EUSART_Write (0x0a);

    tempoTimeout = K_TimeOutMs;
    fTimeout=false;
    fOK=false;
    while (!fOK)
    {
        timeout();
        if (fTimeout)
            break;
    }
    if (fTimeout)
        __RN_flash_GPIO6(10);
    __delay_ms(10);

    // 5) APPeui
    __RN_MacSet();          //  envia "mac set "
    EUSART_Write ('a');    EUSART_Write ('p');    EUSART_Write ('p');
    EUSART_Write ('e');    EUSART_Write ('u');    EUSART_Write ('i');    EUSART_Write (' ');
    for (loop=0;loop<16;loop++)
        EUSART_Write (appeui[loop]);
    EUSART_Write (0x0d);
    EUSART_Write (0x0a);

    tempoTimeout = K_TimeOutMs;
    fTimeout=false;
    fOK=false;
    while (!fOK)
    {
        timeout();
        if (fTimeout)
            break;
    }
    if (fTimeout)
        __RN_flash_GPIO6(10);
    __delay_ms(10);
	
    // 6) Canais off - Ex.: mac set ch status 4 off
    for (loop=8;loop<64;loop++)            // desligo 24 ao 63
    { 
        __RN_ch_off(loop);
        tempoTimeout = K_TimeOutMs;
        fTimeout=false;
        fOK=false;
        while (!fOK)
        {
            timeout();
            if (fTimeout)
                break;
        }
        if (fTimeout)
            __RN_flash_GPIO6(10);
        __delay_ms(10);
    }
    __delay_ms(10);

    for (loop=64;loop<72;loop++)            // desligo 64 ao 71 - teoricamente 64-65-66 poderiam ser usados
    { 
        __RN_ch_off(loop);
        tempoTimeout = K_TimeOutMs;
        fTimeout=false;
        fOK=false;
        while (!fOK)
        {
            timeout();
            if (fTimeout)
                break;
        }
        if (fTimeout)
            __RN_flash_GPIO6(10);
        __delay_ms(10);
    }
    __delay_ms(10);

     // 7) ADR
   __RN_mac_set_adr(1);
    tempoTimeout = K_TimeOutMs;
    fTimeout=false;
    fOK=false;
    while (!fOK)
    {
        timeout();
        if (fTimeout)
            break;
    }
    if (fTimeout)
        __RN_flash_GPIO6(10);
    __delay_ms(10);

     // 8) PWR
    __RN_radio_pwr(20);
    tempoTimeout = K_TimeOutMs;
    fTimeout=false;
    fOK=false;
    while (!fOK)
    {
        timeout();
        if (fTimeout)
            break;
    }
    if (fTimeout)
        __RN_flash_GPIO6(10);
    __delay_ms(10);

     // 9) SF
    __RN_radio_sf(12);
    tempoTimeout = K_TimeOutMs;
    fTimeout=false;
    fOK=false;
    while (!fOK)
    {
        timeout();
        if (fTimeout)
            break;
    }
    if (fTimeout)
        __RN_flash_GPIO6(10);
    __delay_ms(10);
    
    //--------------- ajustes finalizados, salvar !!
    __RN_mac_save();
    tempoTimeout = K_TimeOutMs;
    fTimeout=false;
    fOK=false;
    while (!fOK)
    {
        timeout();
        if (fTimeout)
            break;
    }
    if (fTimeout)
        __RN_flash_GPIO6(10);
    __delay_ms(10);
    
    //--------------- JOIN nw !!
    __RN_mac_join();
    tempoTimeout = K_TimeOutMs;
    fTimeout=false;
    fJoined=false;
    while (!fJoined)
    {
        timeout();
        if (fTimeout)
            break;
    }
    if (fTimeout)
        __RN_flash_GPIO6(10);
    __delay_ms(10);

    //######################################################################
    while (1)
    {
        __RN_WriteGpio(6,1);
#ifdef CURIOSITY
        LED_D4_SetHigh();
#endif
        __delay_ms(500);

        __RN_WriteGpio(6,0);
#ifdef CURIOSITY
        LED_D4_SetLow();
#endif
        __delay_ms(500);
        
        segundos++;
        if (segundos > 14)           // a cada 15 s
        {
            segundos=0;
            lora_port++;
            if (lora_port>223)
                lora_port=1;
        }
        
        if (segundos==0)    
        {   
                   __delay_ms(1);

            // decompoe o lora_port atual em 3 bytes - somar 48 para ASCII
            centena = lora_port / 100;
            resto = lora_port % 100;
            dezena = resto /10;
            unidade = resto % 10;

            EUSART_reset();
            EUSART_Write ('m');    EUSART_Write ('a');    EUSART_Write ('c');    EUSART_Write (' ');
            EUSART_Write ('t');    EUSART_Write ('x');    EUSART_Write (' ');    
            EUSART_Write ('u');    EUSART_Write ('n');    
            EUSART_Write ('c');    EUSART_Write ('n');    EUSART_Write ('f');    EUSART_Write (' ');    

            ///envia o lora_port - 1 a 223
            if (lora_port < 10)               // 1 byte >> 1 caractere
            {
                EUSART_Write (unidade+48);
            }
            else if (lora_port < 100)         // 2 bytes >> 2 caracteres
            {
                EUSART_Write (dezena+48);
                EUSART_Write (unidade+48);
            }
            else                              // 3 bytes >> 3 caracteres
            {
                EUSART_Write (centena+48);
                EUSART_Write (dezena+48);
                EUSART_Write (unidade+48);
            }           
    
            EUSART_Write (' ');    

            // simula um sensor de temperatura
            
            tempSimulada++;
            if (tempSimulada>10)
                tempSimulada=1;
            switch (tempSimulada)
            {
                case 1:
                {centena = 1;    dezena = 9; unidade = 8;    break; }    // 19.8                
                case 2:
                {centena = 2;    dezena = 0; unidade = 4;    break; }    // 20.4                
                case 3:
                {centena = 2;    dezena = 0; unidade = 1;    break; }    // 20.1                
                case 4:
                {centena = 2;    dezena = 2; unidade = 8;    break; }    // 22.8                
                case 5:
                {centena = 1;    dezena = 9; unidade = 4;    break; }    // 19.4                
                case 6:
                {centena = 1;    dezena = 7; unidade = 9;    break; }    // 17.9                
                case 7:
                {centena = 1;    dezena = 8; unidade = 8;    break; }    // 18.8                
                case 8:
                {centena = 2;    dezena = 0; unidade = 6;    break; }    // 20.6                
                case 9:
                {centena = 2;    dezena = 1; unidade = 3;    break; }    // 21.3                
                case 10:
                {centena = 2;    dezena = 2; unidade = 8;    break; }    // 22.8                
  
                default:
                {centena = 2;    dezena = 2; unidade = 0;    break; }    // 22.0
            }
            
//            ///envia o 'payload' 
            
//            if (lora_port < 10)               // 1 byte >> 1 caractere
//            {
//                EUSART_Write (unidade+48);
//            }
//            else if (lora_port < 100)         // 2 bytes >> 2 caracteres
//            {
//                EUSART_Write (dezena+48);
//                EUSART_Write (unidade+48);
//            }
//            else                              // 3 bytes >> 3 caracteres
//            {
                EUSART_Write (centena+48);
                EUSART_Write (dezena+48);
                EUSART_Write (unidade+48);
//            }    

            EUSART_Write (0x0d);
            EUSART_Write (0x0a);

            tempoTimeout = 5000;
            fTimeout=false;
            fTXOK=false;
            while (!fTXOK)
            {
                timeout();
                if (fTimeout)
                    break;
            }
            if (fTimeout)
                __RN_flash_GPIO6(10);
            __delay_ms(10);

            __RN_flash_GPIO6(2);
        }    
    }
}
/** End of File */