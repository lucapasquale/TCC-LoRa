#include "mcc.h"
#include "RN__funcoes.h"

#define  K_TimeOutMs      2000          // x10 = 20.000 ms

///---- flags
extern volatile uint8_t fOK;
extern volatile uint8_t fTXOK;
extern volatile uint8_t fJoined;
extern volatile uint8_t fCRLF;
extern volatile uint8_t fTimeout;

///---- vars interr
extern volatile uint8_t indice;
extern volatile uint8_t DadosRecebidos[64];
extern volatile uint8_t PenultimoDadoRecebido;
extern volatile uint8_t UltimoDadoRecebido;
extern volatile uint16_t   tempoTimeout;

/////////////////////////////////////////////////////////
/////        ... e Funcoes
void __RN_radio_sf(uint8_t qual)      // radio set sf7 -- sf12
{
    EUSART_reset();
    EUSART_Write ('r');    EUSART_Write ('a');    EUSART_Write ('d');    
    EUSART_Write ('i');    EUSART_Write ('o');    EUSART_Write (' ');    
    EUSART_Write ('s');    EUSART_Write ('e');    EUSART_Write ('t');    
    EUSART_Write (' ');    
    EUSART_Write ('s');    EUSART_Write ('f');    EUSART_Write (' ');    
    EUSART_Write ('s');    EUSART_Write ('f');
    switch (qual)
    {
        case  7:{ EUSART_Write ('7'); break;   }
        case  8:{ EUSART_Write ('8'); break;   }
        case  9:{ EUSART_Write ('9'); break;   }
        case 10:{ EUSART_Write ('1'); EUSART_Write ('0'); break;   }
        case 11:{ EUSART_Write ('1'); EUSART_Write ('1'); break;   }
        case 12:{ EUSART_Write ('1'); EUSART_Write ('2'); break;   }
        default:{ EUSART_Write ('1'); EUSART_Write ('2'); break;   }
    }
    EUSART_Write (0x0d);
    EUSART_Write (0x0a);
}    

void __RN_radio_pwr(uint8_t qual)      // radio set pwr [2--17 or 20]
{
    EUSART_reset();
    EUSART_Write ('r');    EUSART_Write ('a');    EUSART_Write ('d');    
    EUSART_Write ('i');    EUSART_Write ('o');    EUSART_Write (' ');    
    EUSART_Write ('s');    EUSART_Write ('e');    EUSART_Write ('t');    
    EUSART_Write (' ');    
    EUSART_Write ('p');    EUSART_Write ('w');    EUSART_Write ('r');    
    EUSART_Write (' ');    
    
    switch (qual)
    {
        case  2:{ EUSART_Write ('2'); break;   }
        case  3:{ EUSART_Write ('3'); break;   }
        case  4:{ EUSART_Write ('4'); break;   }
        case  5:{ EUSART_Write ('5'); break;   }
        case  6:{ EUSART_Write ('6'); break;   }
        case  7:{ EUSART_Write ('7'); break;   }
        case  8:{ EUSART_Write ('8'); break;   }
        case  9:{ EUSART_Write ('9'); break;   }
        case 10:{ EUSART_Write ('1'); EUSART_Write ('0'); break;   }
        case 11:{ EUSART_Write ('1'); EUSART_Write ('1'); break;   }
        case 12:{ EUSART_Write ('1'); EUSART_Write ('2'); break;   }
        case 13:{ EUSART_Write ('1'); EUSART_Write ('3'); break;   }
        case 14:{ EUSART_Write ('1'); EUSART_Write ('4'); break;   }
        case 15:{ EUSART_Write ('1'); EUSART_Write ('5'); break;   }
        case 16:{ EUSART_Write ('1'); EUSART_Write ('6'); break;   }
        case 17:{ EUSART_Write ('1'); EUSART_Write ('7'); break;   }
        case 20:{ EUSART_Write ('2'); EUSART_Write ('0'); break;   }
        default:{ EUSART_Write ('2'); EUSART_Write ('0'); break;   }
    }
    EUSART_Write (0x0d);
    EUSART_Write (0x0a);
}    

void __RN_ch_off(uint8_t qual)      // mac set ch status 4 off
{
uint8_t dez,uni;
    dez = qual / 10;
    uni = qual % 10;

    EUSART_reset();
    EUSART_Write ('m');    EUSART_Write ('a');    EUSART_Write ('c');    EUSART_Write (' ');
    EUSART_Write ('s');    EUSART_Write ('e');    EUSART_Write ('t');    EUSART_Write (' ');
    EUSART_Write ('c');    EUSART_Write ('h');    EUSART_Write (' ');
    EUSART_Write ('s');    EUSART_Write ('t');    EUSART_Write ('a');    
    EUSART_Write ('t');    EUSART_Write ('u');    EUSART_Write ('s');    EUSART_Write (' ');
    EUSART_Write (dez+48);
    EUSART_Write (uni+48);    
    EUSART_Write (' ');
    EUSART_Write ('o');    EUSART_Write ('f');    EUSART_Write ('f');
    EUSART_Write (0x0d);
    EUSART_Write (0x0a);
}

void __RN_mac_set_adr(uint8_t qual)
{
    EUSART_reset();
    EUSART_Write ('m');    EUSART_Write ('a');    EUSART_Write ('c');    EUSART_Write (' ');
    EUSART_Write ('s');    EUSART_Write ('e');    EUSART_Write ('t');    EUSART_Write (' ');
    EUSART_Write ('a');    EUSART_Write ('d');    EUSART_Write ('r');    EUSART_Write (' ');
    EUSART_Write ('o');
    if (qual==0)
    {
        EUSART_Write ('f');    EUSART_Write ('f');
    }
    else
    {
        EUSART_Write ('n');
    }
    EUSART_Write (0x0d);
    EUSART_Write (0x0a);
}
void __RN_mac_join()
{
    EUSART_reset();
    EUSART_Write ('m');    EUSART_Write ('a');    EUSART_Write ('c');    EUSART_Write (' ');
    EUSART_Write ('j');    EUSART_Write ('o');    EUSART_Write ('i');    EUSART_Write ('n');
    EUSART_Write (' ');    EUSART_Write ('a');    EUSART_Write ('b');    EUSART_Write ('p');
    EUSART_Write (0x0d);
    EUSART_Write (0x0a);
}
void __RN_mac_save()
{
    EUSART_reset();
    EUSART_Write ('m');    EUSART_Write ('a');    EUSART_Write ('c');    EUSART_Write (' ');
    EUSART_Write ('s');    EUSART_Write ('a');    EUSART_Write ('v');    EUSART_Write ('e');
    EUSART_Write (0x0d);
    EUSART_Write (0x0a);
}

void __RN_MacSet()  
{
    EUSART_reset();
    EUSART_Write ('m');    EUSART_Write ('a');    EUSART_Write ('c');    EUSART_Write (' ');
    EUSART_Write ('s');    EUSART_Write ('e');    EUSART_Write ('t');    EUSART_Write (' ');
}

uint8_t __RN_ReadGpio(uint8_t qual)
{
    //ex.: sys get pindig GPIO10
    EUSART_reset();
    
    EUSART_Write ('s');    EUSART_Write ('y');    EUSART_Write ('s');    
    EUSART_Write (' ');
    EUSART_Write ('g');    EUSART_Write ('e');    EUSART_Write ('t');    
    EUSART_Write (' ');
    EUSART_Write ('p');    EUSART_Write ('i');    EUSART_Write ('n');    
    EUSART_Write ('d');    EUSART_Write ('i');    EUSART_Write ('g');
    EUSART_Write (' ');
    EUSART_Write ('G');    EUSART_Write ('P');    EUSART_Write ('I');    EUSART_Write ('O');    

    switch (qual)
    {
        case  0:{ EUSART_Write ('0'); break;   }
        case  1:{ EUSART_Write ('1'); break;   }
        case  2:{ EUSART_Write ('2'); break;   }
        case  3:{ EUSART_Write ('3'); break;   }
        case  4:{ EUSART_Write ('4'); break;   }
        case  5:{ EUSART_Write ('5'); break;   }
        case  6:{ EUSART_Write ('6'); break;   }
        case  7:{ EUSART_Write ('7'); break;   }
        case  8:{ EUSART_Write ('8'); break;   }
        case  9:{ EUSART_Write ('9'); break;   }
        case 10:{ EUSART_Write ('1'); EUSART_Write ('0'); break;   }
        case 11:{ EUSART_Write ('1'); EUSART_Write ('1'); break;   }
        case 12:{ EUSART_Write ('1'); EUSART_Write ('2'); break;   }
        case 13:{ EUSART_Write ('1'); EUSART_Write ('3'); break;   }
        case 14:{ EUSART_Write ('1'); EUSART_Write ('4'); break;   }
    }

    EUSART_Write (0x0d);
    EUSART_Write (0x0a);
    
    tempoTimeout = K_TimeOutMs;
    fTimeout=false;
    fCRLF=false;
    while (!fCRLF)
    {
        timeout();
        if (fTimeout)
            break;
    }
    if (fTimeout)
        __RN_flash_GPIO6(10);
    __delay_ms(10);
    
    return DadosRecebidos[0];
}

void __RN_SetGpioIn(uint8_t qual)
{
    //ex.: sys set pinmode GPIO10 digin    
    EUSART_reset();
    
    EUSART_Write ('s');    EUSART_Write ('y');    EUSART_Write ('s');    
    EUSART_Write (' ');
    EUSART_Write ('s');    EUSART_Write ('e');    EUSART_Write ('t');    
    EUSART_Write (' ');
    EUSART_Write ('p');    EUSART_Write ('i');    EUSART_Write ('n');    
    EUSART_Write ('m');    EUSART_Write ('o');    EUSART_Write ('d');    EUSART_Write ('e');    
    EUSART_Write (' ');
    EUSART_Write ('G');    EUSART_Write ('P');    EUSART_Write ('I');    EUSART_Write ('O');    

    switch (qual)
    {
        case  0:{ EUSART_Write ('0'); break;   }
        case  1:{ EUSART_Write ('1'); break;   }
        case  2:{ EUSART_Write ('2'); break;   }
        case  3:{ EUSART_Write ('3'); break;   }
        case  4:{ EUSART_Write ('4'); break;   }
        case  5:{ EUSART_Write ('5'); break;   }
        case  6:{ EUSART_Write ('6'); break;   }
        case  7:{ EUSART_Write ('7'); break;   }
        case  8:{ EUSART_Write ('8'); break;   }
        case  9:{ EUSART_Write ('9'); break;   }
        case 10:{ EUSART_Write ('1'); EUSART_Write ('0'); break;   }
        case 11:{ EUSART_Write ('1'); EUSART_Write ('1'); break;   }
        case 12:{ EUSART_Write ('1'); EUSART_Write ('2'); break;   }
        case 13:{ EUSART_Write ('1'); EUSART_Write ('3'); break;   }
        case 14:{ EUSART_Write ('1'); EUSART_Write ('4'); break;   }
    }
    EUSART_Write (' ');

    EUSART_Write ('d'); EUSART_Write ('i'); EUSART_Write ('g'); 
    EUSART_Write ('i'); EUSART_Write ('n'); 

    EUSART_Write (0x0d);
    EUSART_Write (0x0a);
}

void __RN_WriteGpio(uint8_t qual, uint8_t estado)
{
    //ex.: sys set pindig GPIO13 1    
    EUSART_reset();
    
    EUSART_Write ('s');    EUSART_Write ('y');    EUSART_Write ('s');    
    EUSART_Write (' ');
    EUSART_Write ('s');    EUSART_Write ('e');    EUSART_Write ('t');    
    EUSART_Write (' ');
    EUSART_Write ('p');    EUSART_Write ('i');    EUSART_Write ('n');    
    EUSART_Write ('d');    EUSART_Write ('i');    EUSART_Write ('g');    
    EUSART_Write (' ');
    EUSART_Write ('G');    EUSART_Write ('P');    EUSART_Write ('I');    EUSART_Write ('O');    

    switch (qual)
    {
        case  0:{ EUSART_Write ('0'); break;   }
        case  1:{ EUSART_Write ('1'); break;   }
        case  2:{ EUSART_Write ('2'); break;   }
        case  3:{ EUSART_Write ('3'); break;   }
        case  4:{ EUSART_Write ('4'); break;   }
        case  5:{ EUSART_Write ('5'); break;   }
        case  6:{ EUSART_Write ('6'); break;   }
        case  7:{ EUSART_Write ('7'); break;   }
        case  8:{ EUSART_Write ('8'); break;   }
        case  9:{ EUSART_Write ('9'); break;   }
        case 10:{ EUSART_Write ('1'); EUSART_Write ('0'); break;   }
        case 11:{ EUSART_Write ('1'); EUSART_Write ('1'); break;   }
        case 12:{ EUSART_Write ('1'); EUSART_Write ('2'); break;   }
        case 13:{ EUSART_Write ('1'); EUSART_Write ('3'); break;   }
        case 14:{ EUSART_Write ('1'); EUSART_Write ('4'); break;   }
    }
    EUSART_Write (' ');
    if (estado==0)
        EUSART_Write ('0');
    else
        EUSART_Write ('1');
    EUSART_Write (0x0d);
    EUSART_Write (0x0a);

    tempoTimeout = K_TimeOutMs;
    fTimeout=false;
    fOK=false;
    while (!fOK)
    {
        timeout();
        if (fTimeout)
            break;
    }
//    if (fTimeout)
//        __RN_flash_GPIO6(10);

    __delay_ms(10);
}

void __RN_HWReset()
{
    EUSART_reset();
    rstrn_SetLow();
    __delay_ms(5);
    rstrn_SetHigh();
}

void __RN_SysFactoryReset()
{
    EUSART_reset();

    EUSART_Write ('s');
    EUSART_Write ('y');
    EUSART_Write ('s');
    EUSART_Write (' ');
    EUSART_Write ('f');
    EUSART_Write ('a');
    EUSART_Write ('c');
    EUSART_Write ('t');
    EUSART_Write ('o');
    EUSART_Write ('r');
    EUSART_Write ('y');
    EUSART_Write ('R');
    EUSART_Write ('E');
    EUSART_Write ('S');
    EUSART_Write ('E');
    EUSART_Write ('T');
    EUSART_Write (0x0d);
    EUSART_Write (0x0a);
}

void __RN_SysReset()
{
    EUSART_reset();

    EUSART_Write ('s');         // EUSART_Write ("sys reset");  // ?????
    EUSART_Write ('y');
    EUSART_Write ('s');
    EUSART_Write (' ');
    EUSART_Write ('r');
    EUSART_Write ('e');
    EUSART_Write ('s');
    EUSART_Write ('e');
    EUSART_Write ('t');
    EUSART_Write (0x0d);
    EUSART_Write (0x0a);
}

void __RN_flash_GPIO6(uint8_t counter)
{
uint8_t c;
    for (c=0;c<counter;c++)
    {
        __RN_WriteGpio(6,1);
#ifdef CURIOSITY
        LED_D4_SetHigh();
#endif
        __delay_ms(50);
        __RN_WriteGpio(6,0);
#ifdef CURIOSITY
        LED_D4_SetLow();
#endif
        __delay_ms(50);
    }
}