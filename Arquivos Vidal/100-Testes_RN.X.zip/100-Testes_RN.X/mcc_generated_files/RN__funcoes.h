/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

#ifndef RN__funcoes_H
#define	RN__funcoes_H

#include <xc.h> // include processor files - each processor file is guarded.  

/////////////////////////////////////////////////////////////
//////        Prototipos ...
void timeout(void);
void __RN_SysReset(void);
void __RN_HWReset(void);
void __RN_SysFactoryReset(void);
void __RN_WriteGpio(uint8_t qual, uint8_t estado);      // no reset -> saidas = 0
void __RN_SetGpioIn(uint8_t qual);
uint8_t __RN_ReadGpio(uint8_t qual);
void __RN_MacSet(void);
void __RN_mac_save(void);
void __RN_mac_join(void);
void __RN_mac_set_adr(uint8_t qual);
void __RN_ch_off(uint8_t qual);
void __RN_radio_pwr(uint8_t qual);
void __RN_radio_sf(uint8_t qual);
void __RN_flash_GPIO6(uint8_t counter);
#endif	/* XC_HEADER_TEMPLATE_H */

