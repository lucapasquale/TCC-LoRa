/**  EUSART Generated Driver File  */

#include "eusart.h"

#define EUSART_TX_BUFFER_SIZE 64
#define EUSART_RX_BUFFER_SIZE 64

static uint8_t eusartTxHead = 0;
static uint8_t eusartTxTail = 0;
static uint8_t eusartTxBuffer[EUSART_TX_BUFFER_SIZE];
volatile uint8_t eusartTxBufferRemaining;

static uint8_t eusartRxHead = 0;
static uint8_t eusartRxTail = 0;
static uint8_t eusartRxBuffer[EUSART_RX_BUFFER_SIZE];
volatile uint8_t eusartRxCount;


extern volatile uint8_t fOK;
extern volatile uint8_t fTXOK;
extern volatile uint8_t fJoined;
extern volatile uint8_t fCRLF;
extern volatile uint8_t indice;
extern volatile uint8_t DadosRecebidos[64];
extern volatile uint8_t UltimoDadoRecebido;
extern volatile uint8_t PenultimoDadoRecebido;

void EUSART_reset(void)
{
    // initializing the driver state
    eusartTxHead = 0;
    eusartTxTail = 0;
    eusartTxBufferRemaining = sizeof (eusartTxBuffer);

    eusartRxHead = 0;
    eusartRxTail = 0;
    eusartRxCount = 0;

    /// limpa o buffer
    for(indice=0;indice<64;indice++)
        DadosRecebidos[indice]=0x20;
    indice=0;
    UltimoDadoRecebido=0;
    PenultimoDadoRecebido=0;    
}

void EUSART_Initialize(void)
{
    // disable interrupts before changing states
    PIE1bits.RCIE = 0;
    PIE1bits.TXIE = 0;

    // Set the EUSART module to the options selected in the user interface.

    // ABDOVF no_overflow; SCKP async_noninverted_sync_fallingedge; RCIDL idle; BRG16 16bit_generator; WUE disabled; ABDEN disabled; 
    BAUD1CON = 0x48;

    // SPEN enabled; OERR no_error; RX9 8-bit; RX9D 0x0; CREN enabled; ADDEN disabled; SREN disabled; FERR no_error; 
    RC1STA = 0x90;

    // TRMT TSR_empty; TX9 8-bit; TX9D 0x0; SENDB sync_break_complete; TXEN enabled; SYNC asynchronous; BRGH hi_speed; CSRC slave_mode; 
    TX1STA = 0x26;

    // Baud Rate = 57600; SP1BRGL 68; 
    SPBRGL = 0x44;

    // Baud Rate = 57600; SP1BRGH 0; 
    SPBRGH = 0x00;

    EUSART_reset();     // initializing the driver state
                        //    eusartTxHead = 0;
                        //    eusartTxTail = 0;
                        //    eusartTxBufferRemaining = sizeof (eusartTxBuffer);
                        //
                        //    eusartRxHead = 0;
                        //    eusartRxTail = 0;
                        //    eusartRxCount = 0;

    // enable receive interrupt
    PIE1bits.RCIE = 1;
}

uint8_t EUSART_Read(void)
{
    uint8_t readValue = 0;

    while (0 == eusartRxCount)
    {
    }

    PIE1bits.RCIE = 0;

    readValue = eusartRxBuffer[eusartRxTail++];
    if (sizeof (eusartRxBuffer) <= eusartRxTail)
    {
        eusartRxTail = 0;
    }
    eusartRxCount--;
    PIE1bits.RCIE = 1;

    return readValue;
}

void EUSART_Write(uint8_t txData)
{
    while (0 == eusartTxBufferRemaining)
    {
    }

    if (0 == PIE1bits.TXIE)
    {
        TX1REG = txData;
    }
    else
    {
        PIE1bits.TXIE = 0;
        eusartTxBuffer[eusartTxHead++] = txData;
        if (sizeof (eusartTxBuffer) <= eusartTxHead)
        {
            eusartTxHead = 0;
        }
        eusartTxBufferRemaining--;
    }
    PIE1bits.TXIE = 1;
}

void EUSART_Transmit_ISR(void)
{

    // add your EUSART interrupt custom code
    if (sizeof (eusartTxBuffer) > eusartTxBufferRemaining)
    {
        TX1REG = eusartTxBuffer[eusartTxTail++];
        if (sizeof (eusartTxBuffer) <= eusartTxTail)
        {
            eusartTxTail = 0;
        }
        eusartTxBufferRemaining++;
    }
    else
    {
        PIE1bits.TXIE = 0;
    }
}

void EUSART_Receive_ISR(void)
{
    if (1 == RC1STAbits.OERR)
    {
        RC1STAbits.CREN = 0;
        RC1STAbits.CREN = 1;
    }

    ///// meu tratamento
    PenultimoDadoRecebido = UltimoDadoRecebido;
    UltimoDadoRecebido = RC1REG;
    DadosRecebidos[indice]= UltimoDadoRecebido;
    if (indice<63)
        indice++;

    if (  (PenultimoDadoRecebido=='o') && (UltimoDadoRecebido=='k'))
        fOK=true;

    if (  (PenultimoDadoRecebido==0x0D) && (UltimoDadoRecebido==0x0A))
        fCRLF=true;

    if ( (DadosRecebidos[indice-5]=='t')&&
         (DadosRecebidos[indice-4]=='x')&&
         (DadosRecebidos[indice-2]=='o')&&
         (DadosRecebidos[indice-1]=='k') )
        fTXOK=true;

    if ( (DadosRecebidos[indice-4]=='a')&&
         (DadosRecebidos[indice-3]=='c')&&
         (DadosRecebidos[indice-2]=='c')&&
         (DadosRecebidos[indice-1]=='e') )
        fJoined=true;
    
    ////buffer padrao
    eusartRxBuffer[eusartRxHead++] = UltimoDadoRecebido;
    if (sizeof (eusartRxBuffer) <= eusartRxHead)
    {
        eusartRxHead = 0;
    }
    eusartRxCount++;
}
/**
  End of File
 */
