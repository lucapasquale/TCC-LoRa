/**
  @Generated Pin Manager Header File
 */

#ifndef PIN_MANAGER_H
#define PIN_MANAGER_H

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set LED_D4 aliases
#define LED_D4_TRIS               TRISA5
#define LED_D4_LAT                LATA5
#define LED_D4_PORT               RA5
#define LED_D4_SetHigh()    do { LATA5 = 1; } while(0)
#define LED_D4_SetLow()   do { LATA5 = 0; } while(0)
#define LED_D4_Toggle()   do { LATA5 = ~LATA5; } while(0)
#define LED_D4_GetValue()         RA5
#define LED_D4_SetDigitalInput()    do { TRISA5 = 1; } while(0)
#define LED_D4_SetDigitalOutput()   do { TRISA5 = 0; } while(0)

// get/set RX aliases
#define RX_TRIS               TRISB6
#define RX_LAT                LATB6
#define RX_PORT               RB6
#define RX_WPU                WPUB6
#define RX_SetHigh()    do { LATB6 = 1; } while(0)
#define RX_SetLow()   do { LATB6 = 0; } while(0)
#define RX_Toggle()   do { LATB6 = ~LATB6; } while(0)
#define RX_GetValue()         RB6
#define RX_SetDigitalInput()    do { TRISB6 = 1; } while(0)
#define RX_SetDigitalOutput()   do { TRISB6 = 0; } while(0)

#define RX_SetPullup()    do { WPUB6 = 1; } while(0)
#define RX_ResetPullup()   do { WPUB6 = 0; } while(0)
// get/set TX aliases
#define TX_TRIS               TRISB7
#define TX_LAT                LATB7
#define TX_PORT               RB7
#define TX_WPU                WPUB7
#define TX_SetHigh()    do { LATB7 = 1; } while(0)
#define TX_SetLow()   do { LATB7 = 0; } while(0)
#define TX_Toggle()   do { LATB7 = ~LATB7; } while(0)
#define TX_GetValue()         RB7
#define TX_SetDigitalInput()    do { TRISB7 = 1; } while(0)
#define TX_SetDigitalOutput()   do { TRISB7 = 0; } while(0)

#define TX_SetPullup()    do { WPUB7 = 1; } while(0)
#define TX_ResetPullup()   do { WPUB7 = 0; } while(0)
// get/set rstrn aliases
#define rstrn_TRIS               TRISC7
#define rstrn_LAT                LATC7
#define rstrn_PORT               RC7
#define rstrn_ANS                ANSC7
#define rstrn_SetHigh()    do { LATC7 = 1; } while(0)
#define rstrn_SetLow()   do { LATC7 = 0; } while(0)
#define rstrn_Toggle()   do { LATC7 = ~LATC7; } while(0)
#define rstrn_GetValue()         RC7
#define rstrn_SetDigitalInput()    do { TRISC7 = 1; } while(0)
#define rstrn_SetDigitalOutput()   do { TRISC7 = 0; } while(0)

#define rstrn_SetAnalogMode()   do { ANSC7 = 1; } while(0)
#define rstrn_SetDigitalMode()   do { ANSC7 = 0; } while(0)

/**
 * @Param
    none
 * @Returns
    none
 * @Description
    GPIO and peripheral I/O initialization
 * @Example
    PIN_MANAGER_Initialize();
 */
void PIN_MANAGER_Initialize(void);

/**
 * @Param
    none
 * @Returns
    none
 * @Description
    Interrupt on Change Handling routine
 * @Example
    PIN_MANAGER_IOC();
 */
void PIN_MANAGER_IOC(void);

#endif // PIN_MANAGER_H
/**
 End of File
 */